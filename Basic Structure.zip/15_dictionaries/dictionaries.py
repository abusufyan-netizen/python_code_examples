person = {"name": "Alice", "age": 25}
print(person["name"])