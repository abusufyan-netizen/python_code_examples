colors = ("red", "green", "blue")
print(colors[0])