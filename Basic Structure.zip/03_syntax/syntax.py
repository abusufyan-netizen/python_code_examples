# Python syntax uses indentation to define blocks
if 5 > 2:
    print("Five is greater than two!")