# Python Introduction
print("Welcome to Python Learning!")