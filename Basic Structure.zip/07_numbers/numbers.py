x = 1
y = 2.8
z = 1j
print(x, y, z)