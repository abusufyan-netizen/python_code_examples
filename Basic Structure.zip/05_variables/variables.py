x = 10
y = "Hello"
print(x)
print(y)