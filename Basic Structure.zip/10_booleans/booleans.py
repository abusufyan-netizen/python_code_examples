x = 10
y = 20
print(x > y)
print(bool("Python"))