# Getting Started with Python
print("Python is easy to start with!")