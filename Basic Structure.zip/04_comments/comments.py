# This is a comment
print("Comments are ignored by Python")  # Inline comment