x = int(1.9)
y = float("3")
z = str(100)
print(x, y, z)