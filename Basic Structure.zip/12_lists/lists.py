fruits = ["apple", "banana", "cherry"]
print(fruits[1])
fruits.append("orange")
print(fruits)