x = 5
y = "Hi"
z = 3.14
a = True
print(type(x), type(y), type(z), type(a))