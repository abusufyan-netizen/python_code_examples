items = {"apple", "banana", "cherry"}
items.add("orange")
print(items)