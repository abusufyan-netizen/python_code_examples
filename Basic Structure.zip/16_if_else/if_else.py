age = 18
if age >= 18:
    print("Adult")
else:
    print("Minor")