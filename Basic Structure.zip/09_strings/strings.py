text = "Hello, Python!"
print(text.lower())
print(text.upper())
print(text[0:5])